document.addEventListener('DOMContentLoaded', () => {

    // ================================================================
    //  CONFIGURATION
    //  NOTE: For production, route API calls through a backend proxy
    //  so your API key is never exposed in client-side code.
    //  Replace the fetch URL below with your proxy endpoint, e.g.:
    //    const API_URL = 'https://your-server.com/api/generate';
    // ================================================================
    const API_URL = 'http://localhost:3001/api/generate';
    const MODEL   = 'claude-sonnet-4-20250514';

    // ================================================================
    //  SURVIVOR-CENTRED SYSTEM PROMPT
    //  Update the RESEARCH_CONTEXT block below with your findings.
    //  This acts as embedded "training" guidance for every story.
    // ================================================================
    const SURVIVOR_SYSTEM_PROMPT = `You are an educational storytelling AI for a university research tool teaching sextortion prevention using a survivor-centred approach. Your role is to generate realistic but entirely fictional short stories (350–500 words) for educational purposes.

SURVIVOR-CENTRED PRINCIPLES (follow these strictly):
- Never blame the victim. Always frame the character as someone being manipulated by a deliberate predator.
- The character's choices are responses to manipulation tactics — always name the specific tactic used (e.g., grooming, love bombing, isolation, urgency/panic induction, identity-based leverage).
- Show the character's internal conflict and the emotional weight of the situation with empathy and dignity.
- If the outcome is positive, portray realistic help-seeking behaviour: telling a trusted adult, contacting a hotline, reporting to the platform, or not complying with demands.
- If the outcome is negative or mixed, show the psychological manipulation clearly so readers learn to recognise it — not for shock value, but to build pattern recognition.
- NEVER include graphic sexual descriptions. All content must be clinically appropriate for an educational setting.
- Always end with a brief "What to notice" section (2–3 sentences) that names the specific tactics used in plain language.

RESEARCH CONTEXT (update this section with your study findings):
- Financial sextortion disproportionately affects males aged 14–25, often via fake romantic profiles on gaming platforms and social media.
- Image-based sextortion more frequently targets females, often beginning with relationship-building (grooming) over weeks or months.
- LGBTQ+ individuals who are not yet out face compounded leverage risks — perpetrators may threaten outing alongside image threats.
- Survivors consistently report shame and isolation as the primary barriers to reporting. Stories should normalise help-seeking.
- The most effective protective factor identified is a trusted adult relationship. Stories should model this where possible.
- Payment almost never stops threats — this should be reflected in any financially-focused scenario.`;

    // ================================================================
    //  TONE PROMPTS FOR DISCUSSION / SYNTHESIS
    // ================================================================
    const TONE_PROMPTS = {
        'true-crime': `You are a true crime podcast narrator. Discuss the provided story in a gripping, investigative style. Name the manipulation tactics clearly, express outrage at the perpetrator, and show deep empathy for the victim. Make the listener feel the stakes.`,
        'news':       `You are a journalist presenting a television news segment. Report on the story factually, name the type of crime, cite relevant statistics about sextortion, and include expert recommendations on what young people should do.`,
        'audiobook':  `You are a narrator for an educational audiobook aimed at teenagers. Read and reflect on the story in an immersive, empathetic third-person voice. Pause to explain each manipulation tactic as it unfolds, gently but clearly.`,
        'friend':     `You are a knowledgeable and supportive friend who just read this story. React with genuine empathy, name what happened without minimising it, affirm that it is not the character's fault, and gently explain what steps could be taken.`,
        'educator':   `You are a school counsellor facilitating a debrief after students have read the story. Explain the specific tactics the perpetrator used, why these tactics work psychologically, and what the evidence says about the most effective ways to respond.`
    };

    // ================================================================
    //  AGE OPTIONS (populated into toolbox by JS)
    // ================================================================
    const AGE_OPTIONS = [
        '10 years old','11 years old','12 years old','13 years old',
        '14 years old','15 years old','16 years old','17 years old',
        '18 years old','19 years old','20–24 years old','25–29 years old',
        '30–39 years old','40–49 years old','50+ years old'
    ];

    // ================================================================
    //  GLOBAL STATE
    // ================================================================
    const appState = {
        traits:        [],
        settings:      [],
        gender:        'unknown',
        age:           'unknown',
        currentStory:  '',
        synthesisText: '',
        selectedTone:  'true-crime'
    };

    // ================================================================
    //  DOM REFERENCES
    // ================================================================
    const screens          = document.querySelectorAll('.screen');
    const storyForm        = document.getElementById('story-form');
    const synthesisForm    = document.getElementById('synthesis-form');
    const storyOutput      = document.getElementById('story-output');
    const finalPreview     = document.getElementById('final-story-preview');
    const synthesisOutput  = document.getElementById('synthesis-output');
    const loadingStory     = document.getElementById('loading-story');
    const loadingSynthesis = document.getElementById('loading-synthesis');
    const audioControls    = document.getElementById('audio-controls');
    const stypePreview     = document.getElementById('stype-preview');
    const probBars         = document.getElementById('prob-bars');
    const stypeLabel       = document.getElementById('stype-label');

    // ================================================================
    //  POPULATE AGE TOOLBOX
    // ================================================================
    const ageContainer = document.getElementById('age-items');
    AGE_OPTIONS.forEach(age => {
        const el = document.createElement('div');
        el.className = 'draggable';
        el.draggable = true;
        el.dataset.type = 'age';
        el.textContent = age;
        ageContainer.appendChild(el);
    });

    // ================================================================
    //  SCREEN NAVIGATION
    // ================================================================
    function showScreen(id) {
        screens.forEach(s => s.classList.remove('active'));
        document.getElementById(id).classList.add('active');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    document.getElementById('link-resources').addEventListener('click', e => { e.preventDefault(); showScreen('screen-resources'); });
    document.getElementById('btn-back-to-input').addEventListener('click', () => showScreen('screen-input'));
    document.getElementById('btn-modify').addEventListener('click', () => showScreen('screen-input'));
    document.getElementById('btn-finalize').addEventListener('click', () => {
        finalPreview.textContent = appState.currentStory.substring(0, 500) + (appState.currentStory.length > 500 ? '…' : '');
        showScreen('screen-synthesis');
    });
    document.getElementById('btn-back-to-story').addEventListener('click', () => showScreen('screen-story'));

    // ================================================================
    //  DRAG AND DROP
    // ================================================================
    function setupDragAndDrop() {
        // Make toolbox items draggable
        document.querySelectorAll('.draggable').forEach(chip => {
            chip.addEventListener('dragstart', e => {
                e.dataTransfer.setData('text/plain',  chip.textContent.trim());
                e.dataTransfer.setData('dtype',       chip.dataset.type  || 'trait');
                e.dataTransfer.setData('dgender',     chip.dataset.gender || '');
                e.dataTransfer.effectAllowed = 'copy';
            });
        });

        // Set up drop zones
        ['drop-zone-traits', 'drop-zone-setting'].forEach(zoneId => {
            const zone = document.getElementById(zoneId);

            zone.addEventListener('dragover', e => {
                e.preventDefault();
                zone.classList.add('drag-over');
            });
            zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
            zone.addEventListener('drop', e => {
                e.preventDefault();
                zone.classList.remove('drag-over');

                const text    = e.dataTransfer.getData('text/plain');
                const dtype   = e.dataTransfer.getData('dtype');
                const dgender = e.dataTransfer.getData('dgender');

                // Prevent duplicate tags
                if ([...zone.querySelectorAll('.dropped-tag')].some(t => t.dataset.val === text)) return;

                const placeholder = zone.querySelector('.placeholder-text');
                if (placeholder) placeholder.style.display = 'none';

                const tag = document.createElement('div');
                tag.className = 'dropped-tag' + (dtype === 'age' ? ' age-tag' : dtype === 'setting' ? ' setting-tag' : '');
                tag.dataset.val    = text;
                tag.dataset.dtype  = dtype;
                tag.dataset.gender = dgender;
                tag.innerHTML      = `${text} <span class="remove-tag">&times;</span>`;

                tag.querySelector('.remove-tag').addEventListener('click', () => {
                    tag.remove();
                    if (zone.querySelectorAll('.dropped-tag').length === 0 && placeholder) {
                        placeholder.style.display = '';
                    }
                    syncState();
                    updateProbabilityBars();
                });

                zone.appendChild(tag);
                syncState();
                updateProbabilityBars();
            });
        });
    }

    // ================================================================
    //  STATE SYNC — reads drop zones into appState
    // ================================================================
    function syncState() {
        appState.traits   = [];
        appState.settings = [];
        appState.gender   = 'unknown';
        appState.age      = 'unknown';

        document.querySelectorAll('#drop-zone-traits .dropped-tag').forEach(tag => {
            if (tag.dataset.dtype === 'age') {
                appState.age = tag.dataset.val;
            } else {
                appState.traits.push(tag.dataset.val);
            }
            if (tag.dataset.gender === 'male')   appState.gender = 'male';
            if (tag.dataset.gender === 'female') appState.gender = 'female';
            if (tag.dataset.gender === 'nb')     appState.gender = 'nonbinary';
        });

        document.querySelectorAll('#drop-zone-setting .dropped-tag').forEach(tag => {
            appState.settings.push(tag.dataset.val);
        });
    }

    // ================================================================
    //  SEXTORTION TYPE PROBABILITY ENGINE
    //  Based on research demographics — adjust weights to match
    //  your study findings.
    // ================================================================
    function calcProbabilities(gender, traits, age) {
        let financial = 0.50;
        let sexual    = 0.50;
        let dual      = 0.10;

        const traitStr = traits.join(' ').toLowerCase();
        const ageNum   = parseInt((age || '').replace(/\D/g, '')) || 0;

        // Gender weighting (research-backed)
        if (gender === 'male')     { financial += 0.30; sexual -= 0.20; }
        if (gender === 'female')   { sexual += 0.30; financial -= 0.20; }
        if (gender === 'nonbinary'){ sexual += 0.10; financial += 0.05; }

        // Age weighting
        if (ageNum >= 13 && ageNum <= 17) { sexual += 0.10; financial -= 0.05; }
        if (ageNum >= 18 && ageNum <= 24) { financial += 0.15; }

        // Trait weighting
        if (traitStr.includes('gamer') || traitStr.includes('streamer')) financial += 0.10;
        if (traitStr.includes('lonely') || traitStr.includes('seeking validation') || traitStr.includes('heartbroken')) sexual += 0.15;
        if (traitStr.includes('lgbtq') || traitStr.includes('not out yet')) { dual += 0.15; sexual += 0.10; }
        if (traitStr.includes('trusting'))       sexual    += 0.10;
        if (traitStr.includes('financial stress'))financial += 0.05;
        if (traitStr.includes('dating app'))     sexual    += 0.10;
        if (traitStr.includes('discord') || traitStr.includes('gaming')) financial += 0.08;

        // Normalise to 100%
        const total = financial + sexual;
        financial   = Math.min(0.95, financial / total);
        sexual      = 1 - financial;
        dual        = Math.min(0.30, dual);

        return {
            financial: Math.round(financial * 100),
            sexual:    Math.round(sexual    * 100),
            dual:      Math.round(dual      * 100)
        };
    }

    // ================================================================
    //  PROBABILITY BAR UI
    // ================================================================
    function updateProbabilityBars() {
        syncState();

        if (appState.traits.length === 0 && appState.gender === 'unknown') {
            stypePreview.style.display = 'none';
            return;
        }

        stypePreview.style.display = 'block';
        const p = calcProbabilities(appState.gender, appState.traits, appState.age);

        probBars.innerHTML = `
            <div class="probability-bar">
                <div class="bar-label"><span>Financial sextortion</span><span>${p.financial}%</span></div>
                <div class="bar-track"><div class="bar-fill financial" style="width:${p.financial}%"></div></div>
            </div>
            <div class="probability-bar">
                <div class="bar-label"><span>Image-based / sexual</span><span>${p.sexual}%</span></div>
                <div class="bar-track"><div class="bar-fill sexual" style="width:${p.sexual}%"></div></div>
            </div>
            <div class="probability-bar">
                <div class="bar-label"><span>Dual threat (identity leverage)</span><span>${p.dual}%</span></div>
                <div class="bar-track"><div class="bar-fill dual" style="width:${p.dual}%"></div></div>
            </div>`;
    }

    // ================================================================
    //  STORY GENERATION
    // ================================================================
    storyForm.addEventListener('submit', async e => {
        e.preventDefault();
        syncState();

        const name    = document.getElementById('char-name').value.trim() || 'Alex';
        const outcome = document.getElementById('outcome').value;
        const notes   = document.getElementById('extra-notes').value.trim();
        const probs   = calcProbabilities(appState.gender, appState.traits, appState.age);

        // Build scenario-type guidance for the prompt
        let stypeGuide = '';
        if (probs.financial > probs.sexual) {
            stypeGuide = 'This character is statistically more likely to face FINANCIAL sextortion — a fake romantic or friendly relationship culminating in money demands or gift card requests. Lean toward this scenario type.';
        } else {
            stypeGuide = 'This character is statistically more likely to face IMAGE-BASED / SEXUAL sextortion — manipulation into sharing intimate images followed by threats to distribute them. Lean toward this scenario type.';
        }
        if (probs.dual > 15) {
            stypeGuide += ' There is also a notable chance of identity-based leverage (e.g., threatening to out someone as LGBTQ+).';
        }

        const userPrompt = `${SURVIVOR_SYSTEM_PROMPT}

SEXTORTION TYPE GUIDANCE:
${stypeGuide}

STORY PARAMETERS:
- Character name: ${name}
- Age: ${appState.age}
- Gender: ${appState.gender}
- Traits: ${appState.traits.join(', ') || 'not specified'}
- Setting: ${appState.settings.join(', ') || 'not specified'}
- Outcome direction: ${outcome}
${notes ? '- Additional context: ' + notes : ''}

Write the story now. Begin directly with the story — no preamble or meta-commentary.`;

        // Update UI
        const btn = document.getElementById('btn-generate');
        btn.disabled = true;
        btn.textContent = 'Generating…';
        loadingStory.style.display = 'block';
        storyOutput.textContent = '';
        showScreen('screen-story');

        try {
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model:      MODEL,
                    max_tokens: 1000,
                    messages:   [{ role: 'user', content: userPrompt }]
                })
            });

            const data = await response.json();
            const text = data.content?.map(c => c.text || '').join('') 
                         || 'No response received. Please check your API integration.';

            appState.currentStory = text;
            storyOutput.textContent = text;

            // Show scenario type badge
            const dominant = probs.financial > probs.sexual ? 'Financial sextortion' : 'Image-based sextortion';
            const badgeClass = probs.financial > probs.sexual ? 'badge-financial' : 'badge-sexual';
            stypeLabel.innerHTML = `<span class="badge ${badgeClass}">${dominant} scenario</span>`;

        } catch (err) {
            storyOutput.textContent = `Story generation requires API integration.\n\nTo connect: replace the API_URL constant in script.js with your backend proxy endpoint, and ensure your Anthropic API key is set server-side.\n\nError: ${err.message}`;
        }

        loadingStory.style.display = 'none';
        btn.disabled = false;
        btn.textContent = 'Generate Story';
    });

    // ================================================================
    //  TONE CARD SELECTION
    // ================================================================
    document.querySelectorAll('.tone-card').forEach(card => {
        card.addEventListener('click', () => {
            document.querySelectorAll('.tone-card').forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            appState.selectedTone = card.dataset.tone;
        });
    });

    // ================================================================
    //  SYNTHESIS / DISCUSSION GENERATION
    // ================================================================
    synthesisForm.addEventListener('submit', async e => {
        e.preventDefault();

        const systemPrompt = TONE_PROMPTS[appState.selectedTone];
        const userMessage  = `Here is the educational story:\n\n${appState.currentStory}\n\nProvide the discussion now. End your response with:\n1. The name and a one-sentence description of the primary sextortion tactic used.\n2. One concrete action a young person can take if this happens to them.\n3. Canadian resources: Kids Help Phone 1-800-668-6868, NeedHelpNow.ca, Cybertip.ca\n\nKeep the total response to 300–400 words.`;

        const btn = document.querySelector('#synthesis-form button[type="submit"]');
        btn.disabled = true;
        btn.textContent = 'Generating…';
        loadingSynthesis.style.display = 'block';
        synthesisOutput.style.display = 'none';
        audioControls.style.display   = 'none';

        try {
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model:      MODEL,
                    max_tokens: 1000,
                    system:     systemPrompt,
                    messages:   [{ role: 'user', content: userMessage }]
                })
            });

            const data = await response.json();
            const text = data.content?.map(c => c.text || '').join('')
                         || 'No response received. Please check your API integration.';

            appState.synthesisText = text;
            synthesisOutput.textContent = text;
            synthesisOutput.style.display = 'block';
            audioControls.style.display   = 'flex';

        } catch (err) {
            synthesisOutput.textContent = `Discussion generation requires API integration.\n\nError: ${err.message}`;
            synthesisOutput.style.display = 'block';
        }

        loadingSynthesis.style.display = 'none';
        btn.disabled = false;
        btn.textContent = 'Generate Discussion';
    });

    // ================================================================
    //  VOICE SYNTHESIS — Web Speech API
    //  To upgrade to ElevenLabs: replace the btn-play handler with a
    //  fetch call to https://api.elevenlabs.io/v1/text-to-speech/{voice_id}
    //  and play the returned audio blob.
    // ================================================================
    const voiceSelect = document.getElementById('voice-select');
    const rateSlider  = document.getElementById('rate');
    const pitchSlider = document.getElementById('pitch');

    rateSlider.addEventListener('input',  () => document.getElementById('rate-val').textContent  = parseFloat(rateSlider.value).toFixed(1));
    pitchSlider.addEventListener('input', () => document.getElementById('pitch-val').textContent = parseFloat(pitchSlider.value).toFixed(1));

    function populateVoices() {
        const voices = window.speechSynthesis?.getVoices() || [];
        voiceSelect.innerHTML = '';
        if (voices.length === 0) {
            voiceSelect.innerHTML = '<option>No voices available in this browser</option>';
            return;
        }
        voices.forEach((voice, i) => {
            const opt = document.createElement('option');
            opt.value       = i;
            opt.textContent = `${voice.name} (${voice.lang})`;
            voiceSelect.appendChild(opt);
        });
    }

    if (window.speechSynthesis) {
        populateVoices();
        if (speechSynthesis.onvoiceschanged !== undefined) {
            speechSynthesis.onvoiceschanged = populateVoices;
        }
    }

    document.getElementById('btn-play').addEventListener('click', () => {
        if (!appState.synthesisText) { alert('Please generate the discussion first.'); return; }
        if (!window.speechSynthesis) { alert('Your browser does not support the Web Speech API.'); return; }

        speechSynthesis.cancel();
        const utt   = new SpeechSynthesisUtterance(appState.synthesisText);
        const voices = speechSynthesis.getVoices();
        if (voices[parseInt(voiceSelect.value)]) utt.voice = voices[parseInt(voiceSelect.value)];
        utt.rate  = parseFloat(rateSlider.value);
        utt.pitch = parseFloat(pitchSlider.value);
        speechSynthesis.speak(utt);
    });

    document.getElementById('btn-stop').addEventListener('click', () => {
        if (window.speechSynthesis) speechSynthesis.cancel();
    });

    // ================================================================
    //  INIT
    // ================================================================
    setupDragAndDrop();

});
