// proxy-server.js
// Simple backend proxy for the Sextortion Prevention Tool
//
// SETUP:
//   1. Install dependencies:  npm install express cors node-fetch
//   2. Set your API key:      set ANTHROPIC_API_KEY=your-key-here  (Windows)
//                              export ANTHROPIC_API_KEY=your-key-here (Mac/Linux)
//   3. Start the server:      node proxy-server.js
//   4. In script.js, change:  const API_URL = 'http://localhost:3001/api/generate';

const express   = require('express');
const cors      = require('cors');
const fetch     = require('node-fetch');

const app  = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

app.post('/api/generate', async (req, res) => {
    const apiKey = process.env.ANTHROPIC_API_KEY;

    if (!apiKey) {
        return res.status(500).json({ error: 'ANTHROPIC_API_KEY environment variable is not set.' });
    }

    try {
        const response = await fetch('https://api.anthropic.com/v1/messages', {
            method:  'POST',
            headers: {
                'Content-Type':      'application/json',
                'x-api-key':         apiKey,
                'anthropic-version': '2023-06-01'
            },
            body: JSON.stringify(req.body)
        });

        const data = await response.json();
        res.json(data);

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.listen(PORT, () => {
    console.log(`Proxy server running at http://localhost:${PORT}`);
    console.log(`Point your script.js API_URL to: http://localhost:${PORT}/api/generate`);
});
